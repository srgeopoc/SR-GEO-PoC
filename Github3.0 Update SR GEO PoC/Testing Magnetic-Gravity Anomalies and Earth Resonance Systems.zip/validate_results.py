#!/usr/bin/env python3
"""
Validation and predictive overlap testing for the Magnetic-Gravity Anomalies project.
This script validates the Tesla-GRAVEM model results and tests for predictive overlap
between magnetic fluctuations and microgravity anomalies.
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import seaborn as sns
from scipy import stats, signal
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Set paths
DATA_DIR = "/home/ubuntu/magnetic_gravity_project/data"
PROCESSED_DIR = "/home/ubuntu/magnetic_gravity_project/data/processed"
MODEL_DIR = "/home/ubuntu/magnetic_gravity_project/model"
VISUALIZATION_DIR = "/home/ubuntu/magnetic_gravity_project/visualizations"
VALIDATION_DIR = "/home/ubuntu/magnetic_gravity_project/validation"

# Ensure directories exist
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)
os.makedirs(VALIDATION_DIR, exist_ok=True)

def load_model_data():
    """Load Tesla-GRAVEM model data for validation."""
    print("Loading model data for validation...")
    
    try:
        # Load final model data
        model_file = os.path.join(MODEL_DIR, "tesla_gravem_final_model.csv")
        model_data = pd.read_csv(model_file)
        print(f"Successfully loaded {len(model_data)} model data records.")
        
        # Load time series data
        time_series_file = os.path.join(PROCESSED_DIR, "simulated_time_series.csv")
        time_series = pd.read_csv(time_series_file)
        time_series['date'] = pd.to_datetime(time_series['date'])
        print(f"Successfully loaded {len(time_series)} time series records.")
        
        return model_data, time_series
    except Exception as e:
        print(f"Error loading data: {e}")
        return None, None

def validate_model_consistency(model_data):
    """
    Validate internal consistency of the Tesla-GRAVEM model.
    Check relationships between model layers and physical plausibility.
    """
    print("Validating model internal consistency...")
    
    validation_results = {
        'tests': [],
        'results': [],
        'passed': []
    }
    
    # Test 1: Check if vortex strength is related to latitude (should be stronger near equator)
    corr_lat_vortex = stats.pearsonr(np.abs(model_data['lat_grid']), model_data['vortex_strength'])
    test1_passed = corr_lat_vortex[0] < 0  # Negative correlation expected (stronger at equator)
    validation_results['tests'].append("Vortex strength decreases with latitude magnitude")
    validation_results['results'].append(f"Correlation: {corr_lat_vortex[0]:.4f} (p-value: {corr_lat_vortex[1]:.4f})")
    validation_results['passed'].append(test1_passed)
    
    # Test 2: Check if phase coherence is related to magnetic anomaly
    corr_mag_coherence = stats.pearsonr(np.abs(model_data['magnetic_anomaly']), model_data['phase_coherence'])
    test2_passed = corr_mag_coherence[0] > 0  # Positive correlation expected
    validation_results['tests'].append("Phase coherence increases with magnetic field strength")
    validation_results['results'].append(f"Correlation: {corr_mag_coherence[0]:.4f} (p-value: {corr_mag_coherence[1]:.4f})")
    validation_results['passed'].append(test2_passed)
    
    # Test 3: Check if magneto-gravity coupling is influenced by both gravity and magnetic anomalies
    corr_grav_coupling = stats.pearsonr(np.abs(model_data['bouguer_anomaly']), model_data['magneto_gravity_coupling'])
    corr_mag_coupling = stats.pearsonr(np.abs(model_data['magnetic_anomaly']), model_data['magneto_gravity_coupling'])
    test3_passed = (corr_grav_coupling[0] > 0) and (corr_mag_coupling[0] > 0)  # Both should have positive correlation
    validation_results['tests'].append("Magneto-gravity coupling influenced by both gravity and magnetic fields")
    validation_results['results'].append(f"Gravity correlation: {corr_grav_coupling[0]:.4f}, Magnetic correlation: {corr_mag_coupling[0]:.4f}")
    validation_results['passed'].append(test3_passed)
    
    # Test 4: Check if SR intensity modulates the coupling (should see correlation)
    corr_sr_coupling = stats.pearsonr(model_data['sr_intensity'], model_data['magneto_gravity_coupling'])
    test4_passed = abs(corr_sr_coupling[0]) > 0.1  # Should have some correlation (positive or negative)
    validation_results['tests'].append("SR intensity modulates magneto-gravity coupling")
    validation_results['results'].append(f"Correlation: {corr_sr_coupling[0]:.4f} (p-value: {corr_sr_coupling[1]:.4f})")
    validation_results['passed'].append(test4_passed)
    
    # Test 5: Check if model values are within reasonable ranges
    test5_passed = (
        (model_data['vortex_strength'] >= 0).all() and
        (model_data['phase_coherence'] >= 0).all() and
        (model_data['magneto_gravity_coupling'] >= 0).all()
    )
    validation_results['tests'].append("Model values within reasonable ranges (non-negative)")
    validation_results['results'].append(f"All values non-negative: {test5_passed}")
    validation_results['passed'].append(test5_passed)
    
    # Calculate overall validation score
    validation_score = sum(validation_results['passed']) / len(validation_results['passed']) * 100
    
    # Print validation results
    print("\nModel Consistency Validation Results:")
    for i in range(len(validation_results['tests'])):
        status = "PASSED" if validation_results['passed'][i] else "FAILED"
        print(f"Test {i+1}: {validation_results['tests'][i]} - {status}")
        print(f"  Result: {validation_results['results'][i]}")
    
    print(f"\nOverall validation score: {validation_score:.1f}%")
    
    # Save validation results to file
    with open(os.path.join(VALIDATION_DIR, "model_consistency_validation.txt"), "w") as f:
        f.write("Tesla-GRAVEM Model Consistency Validation Results:\n\n")
        for i in range(len(validation_results['tests'])):
            status = "PASSED" if validation_results['passed'][i] else "FAILED"
            f.write(f"Test {i+1}: {validation_results['tests'][i]} - {status}\n")
            f.write(f"  Result: {validation_results['results'][i]}\n\n")
        
        f.write(f"Overall validation score: {validation_score:.1f}%\n")
    
    return validation_results, validation_score

def test_predictive_overlap(model_data, time_series):
    """
    Test predictive overlap between magnetic fluctuations and microgravity anomalies.
    Uses the model to predict gravity variations from magnetic data and vice versa.
    """
    print("Testing predictive overlap...")
    
    # For spatial predictive testing, we'll use the model data
    # Split data into training and testing sets
    X = model_data[['magnetic_anomaly', 'sr_intensity', 'lat_grid', 'lon_grid']]
    y = model_data['bouguer_anomaly']
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
    
    # Train a linear regression model to predict gravity from magnetic + SR data
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Calculate metrics
    mse = mean_squared_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    
    print(f"Spatial prediction results:")
    print(f"Mean Squared Error: {mse:.2f}")
    print(f"R² Score: {r2:.4f}")
    
    # Create scatter plot of predicted vs actual gravity values
    plt.figure(figsize=(10, 8))
    plt.scatter(y_test, y_pred, alpha=0.5)
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
    plt.xlabel('Actual Gravity Anomaly (mGal)')
    plt.ylabel('Predicted Gravity Anomaly (mGal)')
    plt.title('Predictive Overlap: Actual vs Predicted Gravity Anomalies')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'predictive_overlap_spatial.png'), dpi=300)
    plt.close()
    
    # For temporal predictive testing, we'll use the time series data
    # We'll test if Kp index can predict gravity variations with some time lag
    
    # Create lagged features (1-3 days)
    time_df = time_series.copy()
    for lag in range(1, 4):
        time_df[f'kp_lag_{lag}'] = time_df['kp_index'].shift(lag)
        time_df[f'sr_lag_{lag}'] = time_df['sr_amplitude'].shift(lag)
    
    # Drop rows with NaN values from the lag
    time_df = time_df.dropna()
    
    # Split data
    X_time = time_df[[col for col in time_df.columns if 'lag' in col]]
    y_time = time_df['gravity_variation']
    
    X_time_train, X_time_test, y_time_train, y_time_test = train_test_split(
        X_time, y_time, test_size=0.3, random_state=42
    )
    
    # Train model
    time_model = LinearRegression()
    time_model.fit(X_time_train, y_time_train)
    
    # Make predictions
    y_time_pred = time_model.predict(X_time_test)
    
    # Calculate metrics
    time_mse = mean_squared_error(y_time_test, y_time_pred)
    time_r2 = r2_score(y_time_test, y_time_pred)
    
    print(f"\nTemporal prediction results:")
    print(f"Mean Squared Error: {time_mse:.2f}")
    print(f"R² Score: {time_r2:.4f}")
    
    # Create time series plot showing actual vs predicted gravity variations
    plt.figure(figsize=(12, 6))
    
    # Sort by index to ensure chronological order
    sorted_indices = y_time_test.index.sort_values()
    plt.plot(sorted_indices, y_time_test.loc[sorted_indices], 'b-', label='Actual Gravity Variation')
    plt.plot(sorted_indices, y_time_pred[sorted_indices.argsort()], 'r--', label='Predicted Gravity Variation')
    
    plt.xlabel('Time Point')
    plt.ylabel('Gravity Variation (mGal)')
    plt.title('Predictive Overlap: Actual vs Predicted Gravity Variations Over Time')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'predictive_overlap_temporal.png'), dpi=300)
    plt.close()
    
    # Calculate feature importance for both models
    spatial_importance = pd.DataFrame({
        'Feature': X.columns,
        'Importance': np.abs(model.coef_)
    }).sort_values('Importance', ascending=False)
    
    temporal_importance = pd.DataFrame({
        'Feature': X_time.columns,
        'Importance': np.abs(time_model.coef_)
    }).sort_values('Importance', ascending=False)
    
    # Save prediction results to file
    with open(os.path.join(VALIDATION_DIR, "predictive_overlap_results.txt"), "w") as f:
        f.write("Predictive Overlap Test Results:\n\n")
        f.write("Spatial Prediction (Magnetic → Gravity):\n")
        f.write(f"Mean Squared Error: {mse:.2f}\n")
        f.write(f"R² Score: {r2:.4f}\n\n")
        
        f.write("Feature Importance (Spatial):\n")
        for i, row in spatial_importance.iterrows():
            f.write(f"{row['Feature']}: {row['Importance']:.4f}\n")
        
        f.write("\nTemporal Prediction (Lagged Kp/SR → Gravity):\n")
        f.write(f"Mean Squared Error: {time_mse:.2f}\n")
        f.write(f"R² Score: {time_r2:.4f}\n\n")
        
        f.write("Feature Importance (Temporal):\n")
        for i, row in temporal_importance.iterrows():
            f.write(f"{row['Feature']}: {row['Importance']:.4f}\n")
    
    # Create feature importance visualizations
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=spatial_importance)
    plt.title('Feature Importance for Spatial Gravity Prediction')
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'feature_importance_spatial.png'), dpi=300)
    plt.close()
    
    plt.figure(figsize=(10, 6))
    sns.barplot(x='Importance', y='Feature', data=temporal_importance)
    plt.title('Feature Importance for Temporal Gravity Prediction')
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'feature_importance_temporal.png'), dpi=300)
    plt.close()
    
    return {
        'spatial': {
            'mse': mse,
            'r2': r2,
            'importance': spatial_importance
        },
        'temporal': {
            'mse': time_mse,
            'r2': time_r2,
            'importance': temporal_importance
        }
    }

def create_validation_summary(validation_results, predictive_results):
    """Create a summary of validation and predictive overlap results."""
    print("Creating validation summary...")
    
    # Calculate overall validation score
    validation_score = sum(validation_results['passed']) / len(validation_results['passed']) * 100
    
    # Calculate predictive power score
    spatial_score = max(0, predictive_results['spatial']['r2']) * 100
    temporal_score = max(0, predictive_results['temporal']['r2']) * 100
    predictive_score = (spatial_score + temporal_score) / 2
    
    # Create summary visualization
    plt.figure(figsize=(12, 8))
    
    # Create a bar chart with validation and prediction scores
    scores = [validation_score, spatial_score, temporal_score, predictive_score]
    labels = ['Model Consistency', 'Spatial Prediction', 'Temporal Prediction', 'Overall Prediction']
    colors = ['#3498db', '#2ecc71', '#e74c3c', '#f39c12']
    
    bars = plt.bar(labels, scores, color=colors, alpha=0.7)
    
    # Add value labels on top of bars
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 1,
                 f'{height:.1f}%', ha='center', va='bottom')
    
    plt.ylim(0, 110)  # Leave room for text
    plt.axhline(y=50, color='r', linestyle='--', alpha=0.3)  # Add reference line at 50%
    plt.title('Tesla-GRAVEM Model Validation Summary')
    plt.ylabel('Score (%)')
    plt.grid(axis='y', alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'validation_summary.png'), dpi=300)
    plt.close()
    
    # Create a comprehensive summary text file
    with open(os.path.join(VALIDATION_DIR, "validation_summary.txt"), "w") as f:
        f.write("TESLA-GRAVEM MODEL VALIDATION SUMMARY\n")
        f.write("====================================\n\n")
        
        f.write("MODEL CONSISTENCY VALIDATION\n")
        f.write("--------------------------\n")
        for i in range(len(validation_results['tests'])):
            status = "PASSED" if validation_results['passed'][i] else "FAILED"
            f.write(f"Test {i+1}: {validation_results['tests'][i]} - {status}\n")
            f.write(f"  Result: {validation_results['results'][i]}\n\n")
        
        f.write(f"Overall model consistency score: {validation_score:.1f}%\n\n")
        
        f.write("PREDICTIVE OVERLAP TESTING\n")
        f.write("-------------------------\n")
        f.write("Spatial Prediction (Magnetic → Gravity):\n")
        f.write(f"Mean Squared Error: {predictive_results['spatial']['mse']:.2f}\n")
        f.write(f"R² Score: {predictive_results['spatial']['r2']:.4f}\n")
        f.write(f"Predictive Power: {spatial_score:.1f}%\n\n")
        
        f.write("Top 3 Spatial Predictors:\n")
        for i, row in predictive_results['spatial']['importance'].head(3).iterrows():
            f.write(f"  {row['Feature']}: {row['Importance']:.4f}\n")
        
        f.write("\nTemporal Prediction (Lagged Kp/SR → Gravity):\n")
        f.write(f"Mean Squared Error: {predictive_results['temporal']['mse']:.2f}\n")
        f.write(f"R² Score: {predictive_results['temporal']['r2']:.4f}\n")
        f.write(f"Predictive Power: {temporal_score:.1f}%\n\n")
        
        f.write("Top 3 Temporal Predictors:\n")
        for i, row in predictive_results['temporal']['importance'].head(3).iterrows():
            f.write(f"  {row['Feature']}: {row['Importance']:.4f}\n")
        
        f.write(f"\nOVERALL PREDICTIVE POWER: {predictive_score:.1f}%\n\n")
        
        f.write("CONCLUSION\n")
        f.write("----------\n")
        if validation_score >= 80 and predictive_score >= 50:
            f.write
(Content truncated due to size limit. Use line ranges to read in chunks)