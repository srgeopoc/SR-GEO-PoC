#!/usr/bin/env python3
"""
Create time series overlays for the Magnetic-Gravity Anomalies project.
This script generates simulated magnetic and Schumann resonance data 
to overlay with the processed gravity data for visualization.
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import random

# Set paths
DATA_DIR = "/home/ubuntu/magnetic_gravity_project/data"
PROCESSED_DIR = "/home/ubuntu/magnetic_gravity_project/data/processed"
VISUALIZATION_DIR = "/home/ubuntu/magnetic_gravity_project/visualizations"

# Ensure directories exist
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)

def load_gravity_data():
    """Load processed gravity data."""
    print("Loading processed gravity data...")
    try:
        gravity_file = os.path.join(PROCESSED_DIR, "processed_gravity_data.csv")
        df = pd.read_csv(gravity_file)
        print(f"Successfully loaded {len(df)} gravity records.")
        return df
    except Exception as e:
        print(f"Error loading gravity data: {e}")
        return None

def generate_simulated_data(start_date, num_days=30):
    """
    Generate simulated magnetic index (Kp) and Schumann Resonance data
    for demonstration purposes until real data is acquired.
    """
    print("Generating simulated magnetic and SR data...")
    
    # Create date range
    dates = [start_date + timedelta(days=i) for i in range(num_days)]
    
    # Simulate Kp index (0-9 scale)
    # Add some realistic patterns - higher values every ~14 days to simulate geomagnetic storms
    base_kp = [random.uniform(1, 3) for _ in range(num_days)]
    storm_pattern = np.sin(np.linspace(0, 2*np.pi, num_days)) * 2 + 2
    kp_index = np.clip(np.array(base_kp) + storm_pattern, 0, 9)
    
    # Simulate Schumann Resonance amplitude (arbitrary units)
    # Base level with daily variation and occasional spikes
    base_sr = np.random.normal(100, 10, num_days)
    daily_variation = 15 * np.sin(np.linspace(0, 2*np.pi*num_days, num_days))
    # Add occasional spikes that correlate with Kp spikes
    sr_spikes = np.zeros(num_days)
    for i in range(num_days):
        if kp_index[i] > 5:  # If Kp is high, add SR spike with some delay
            spike_idx = min(i + random.randint(0, 2), num_days - 1)
            sr_spikes[spike_idx] = random.uniform(20, 50)
    
    sr_amplitude = base_sr + daily_variation + sr_spikes
    
    # Simulate gravity variation (simplified, based on real gravity data statistics)
    # We'll use a combination of random noise and correlation with Kp
    gravity_base = np.random.normal(-50, 20, num_days)
    # Add correlation with Kp (with 1-2 day delay)
    gravity_correlation = np.zeros(num_days)
    for i in range(num_days):
        if i > 1:  # Skip first days to allow for delay
            # Higher Kp 1-2 days ago may correlate with gravity changes
            kp_effect = kp_index[i-random.randint(1, 2)] * random.uniform(2, 5)
            gravity_correlation[i] = kp_effect
    
    gravity_variation = gravity_base + gravity_correlation
    
    # Create DataFrame
    df = pd.DataFrame({
        'date': dates,
        'kp_index': kp_index,
        'sr_amplitude': sr_amplitude,
        'gravity_variation': gravity_variation
    })
    
    return df

def create_time_series_overlays(sim_data):
    """Create time series overlay visualizations."""
    print("Creating time series overlays...")
    
    # Convert dates to strings for plotting
    date_strs = [d.strftime('%Y-%m-%d') for d in sim_data['date']]
    
    # Plot 1: Kp index and gravity variation overlay
    fig, ax1 = plt.figure(figsize=(14, 8)), plt.gca()
    
    # Plot Kp index
    ax1.plot(date_strs, sim_data['kp_index'], 'b-', label='Kp Index')
    ax1.set_xlabel('Date')
    ax1.set_ylabel('Kp Index', color='b')
    ax1.tick_params(axis='y', labelcolor='b')
    ax1.set_ylim(0, 10)  # Kp index range
    
    # Create second y-axis for gravity variation
    ax2 = ax1.twinx()
    ax2.plot(date_strs, sim_data['gravity_variation'], 'g-', label='Gravity Variation')
    ax2.set_ylabel('Gravity Variation (mGal)', color='g')
    ax2.tick_params(axis='y', labelcolor='g')
    
    # Add title and legend
    plt.title('Magnetic Index (Kp) and Gravity Variation Overlay')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
    
    # Rotate x-axis labels for better readability
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save the figure
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'kp_gravity_overlay.png'), dpi=300)
    plt.close()
    
    # Plot 2: SR amplitude and gravity variation overlay
    fig, ax1 = plt.figure(figsize=(14, 8)), plt.gca()
    
    # Plot SR amplitude
    ax1.plot(date_strs, sim_data['sr_amplitude'], 'r-', label='SR Amplitude')
    ax1.set_xlabel('Date')
    ax1.set_ylabel('SR Amplitude (arbitrary units)', color='r')
    ax1.tick_params(axis='y', labelcolor='r')
    
    # Create second y-axis for gravity variation
    ax2 = ax1.twinx()
    ax2.plot(date_strs, sim_data['gravity_variation'], 'g-', label='Gravity Variation')
    ax2.set_ylabel('Gravity Variation (mGal)', color='g')
    ax2.tick_params(axis='y', labelcolor='g')
    
    # Add title and legend
    plt.title('Schumann Resonance Amplitude and Gravity Variation Overlay')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
    
    # Rotate x-axis labels for better readability
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save the figure
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'sr_gravity_overlay.png'), dpi=300)
    plt.close()
    
    # Plot 3: All three variables overlay
    fig, ax1 = plt.figure(figsize=(14, 10)), plt.gca()
    
    # Plot Kp index
    ax1.plot(date_strs, sim_data['kp_index'], 'b-', label='Kp Index')
    ax1.set_xlabel('Date')
    ax1.set_ylabel('Kp Index', color='b')
    ax1.tick_params(axis='y', labelcolor='b')
    ax1.set_ylim(0, 10)  # Kp index range
    
    # Create second y-axis for SR amplitude
    ax2 = ax1.twinx()
    ax2.plot(date_strs, sim_data['sr_amplitude'], 'r-', label='SR Amplitude')
    ax2.set_ylabel('SR Amplitude (arbitrary units)', color='r')
    ax2.tick_params(axis='y', labelcolor='r')
    
    # Create third y-axis for gravity variation (as a separate plot below)
    ax3 = plt.subplot(2, 1, 2, sharex=ax1)
    ax3.plot(date_strs, sim_data['gravity_variation'], 'g-', label='Gravity Variation')
    ax3.set_xlabel('Date')
    ax3.set_ylabel('Gravity Variation (mGal)', color='g')
    ax3.tick_params(axis='y', labelcolor='g')
    
    # Add titles and legends
    ax1.set_title('Magnetic Index (Kp), SR Amplitude, and Gravity Variation Overlay')
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper right')
    ax3.legend(loc='upper right')
    
    # Rotate x-axis labels for better readability
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Save the figure
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'kp_sr_gravity_overlay.png'), dpi=300)
    plt.close()
    
    print(f"Time series overlays saved to {VISUALIZATION_DIR}")
    
    # Save the simulated data for future use
    sim_data.to_csv(os.path.join(PROCESSED_DIR, 'simulated_time_series.csv'), index=False)
    print(f"Simulated time series data saved to {PROCESSED_DIR}")

def main():
    """Main function to create time series overlays."""
    print("Starting time series overlay creation...")
    
    # Load gravity data
    gravity_df = load_gravity_data()
    
    if gravity_df is not None:
        # Generate simulated data for magnetic index and SR amplitude
        # Use current date as starting point
        start_date = datetime.now() - timedelta(days=30)  # Start 30 days ago
        sim_data = generate_simulated_data(start_date)
        
        # Create time series overlays
        create_time_series_overlays(sim_data)
        
        print("Time series overlay creation completed successfully.")
    else:
        print("Failed to create overlays due to missing gravity data.")

if __name__ == "__main__":
    main()
