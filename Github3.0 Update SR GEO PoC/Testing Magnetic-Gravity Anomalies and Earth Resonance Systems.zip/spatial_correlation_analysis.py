#!/usr/bin/env python3
"""
Analyze spatial correlation between gravity anomalies and simulated magnetic/SR data
for the Magnetic-Gravity Anomalies project.
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from scipy import stats
from matplotlib.colors import LinearSegmentedColormap
import seaborn as sns
from datetime import datetime, timedelta

# Set paths
DATA_DIR = "/home/ubuntu/magnetic_gravity_project/data"
PROCESSED_DIR = "/home/ubuntu/magnetic_gravity_project/data/processed"
VISUALIZATION_DIR = "/home/ubuntu/magnetic_gravity_project/visualizations"

# Ensure directories exist
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)

def load_data():
    """Load processed gravity data and simulated time series data."""
    print("Loading processed data...")
    
    try:
        # Load gravity data
        gravity_file = os.path.join(PROCESSED_DIR, "processed_gravity_data.csv")
        gravity_df = pd.read_csv(gravity_file)
        print(f"Successfully loaded {len(gravity_df)} gravity records.")
        
        # Load simulated time series data
        sim_file = os.path.join(PROCESSED_DIR, "simulated_time_series.csv")
        sim_df = pd.read_csv(sim_file)
        sim_df['date'] = pd.to_datetime(sim_df['date'])
        print(f"Successfully loaded {len(sim_df)} simulated time series records.")
        
        return gravity_df, sim_df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None, None

def generate_spatial_grid(gravity_df, grid_size=0.5):
    """
    Generate a spatial grid from gravity data for correlation analysis.
    
    Args:
        gravity_df: DataFrame containing gravity data with latitude and longitude
        grid_size: Size of grid cells in degrees
        
    Returns:
        DataFrame with gridded gravity data
    """
    print("Generating spatial grid...")
    
    # Round coordinates to grid size
    gravity_df['lat_grid'] = np.round(gravity_df['latitude'] / grid_size) * grid_size
    gravity_df['lon_grid'] = np.round(gravity_df['longitude'] / grid_size) * grid_size
    
    # Group by grid cells and calculate mean values
    grid_df = gravity_df.groupby(['lat_grid', 'lon_grid']).agg({
        'bouguer_anomaly': 'mean',
        'free_air_anomaly': 'mean',
        'obs_grav': 'mean'
    }).reset_index()
    
    print(f"Created spatial grid with {len(grid_df)} cells.")
    return grid_df

def simulate_magnetic_spatial_data(grid_df, correlation_strength=0.4, noise_level=0.6):
    """
    Simulate magnetic field data with partial correlation to gravity anomalies.
    
    Args:
        grid_df: DataFrame with gridded gravity data
        correlation_strength: Strength of correlation with gravity (0-1)
        noise_level: Amount of random noise to add (0-1)
        
    Returns:
        DataFrame with added simulated magnetic field values
    """
    print("Simulating spatial magnetic field data...")
    
    # Create a copy to avoid modifying the original
    result_df = grid_df.copy()
    
    # Normalize gravity anomaly for correlation base
    norm_gravity = (result_df['bouguer_anomaly'] - result_df['bouguer_anomaly'].mean()) / result_df['bouguer_anomaly'].std()
    
    # Generate correlated component
    correlated_component = norm_gravity * correlation_strength
    
    # Generate random noise component
    noise_component = np.random.normal(0, 1, len(result_df)) * noise_level
    
    # Combine components to create magnetic field anomaly
    # Add some regional trends and patterns
    lat_trend = (result_df['lat_grid'] - result_df['lat_grid'].mean()) / result_df['lat_grid'].std() * 0.3
    lon_trend = (result_df['lon_grid'] - result_df['lon_grid'].mean()) / result_df['lon_grid'].std() * 0.2
    
    result_df['magnetic_anomaly'] = correlated_component + noise_component + lat_trend - lon_trend
    
    # Scale to realistic values (nT)
    result_df['magnetic_anomaly'] = result_df['magnetic_anomaly'] * 50 + 10
    
    # Simulate SR intensity with different correlation pattern
    # SR tends to have more regional patterns
    sr_correlated = norm_gravity * 0.25  # Lower correlation with gravity
    sr_noise = np.random.normal(0, 1, len(result_df)) * 0.8
    sr_regional = np.sin(result_df['lat_grid'] / 5) * np.cos(result_df['lon_grid'] / 4) * 0.5
    
    result_df['sr_intensity'] = sr_correlated + sr_noise + sr_regional
    
    # Scale to arbitrary units
    result_df['sr_intensity'] = result_df['sr_intensity'] * 20 + 100
    
    return result_df

def calculate_correlation_metrics(spatial_df):
    """Calculate correlation metrics between gravity, magnetic, and SR data."""
    print("Calculating correlation metrics...")
    
    # Calculate Pearson correlation
    pearson_grav_mag = stats.pearsonr(spatial_df['bouguer_anomaly'], spatial_df['magnetic_anomaly'])
    pearson_grav_sr = stats.pearsonr(spatial_df['bouguer_anomaly'], spatial_df['sr_intensity'])
    pearson_mag_sr = stats.pearsonr(spatial_df['magnetic_anomaly'], spatial_df['sr_intensity'])
    
    # Calculate Spearman rank correlation
    spearman_grav_mag = stats.spearmanr(spatial_df['bouguer_anomaly'], spatial_df['magnetic_anomaly'])
    spearman_grav_sr = stats.spearmanr(spatial_df['bouguer_anomaly'], spatial_df['sr_intensity'])
    spearman_mag_sr = stats.spearmanr(spatial_df['magnetic_anomaly'], spatial_df['sr_intensity'])
    
    # Print results
    print("\nCorrelation Analysis Results:")
    print(f"Gravity-Magnetic Pearson correlation: {pearson_grav_mag[0]:.4f} (p-value: {pearson_grav_mag[1]:.4f})")
    print(f"Gravity-SR Pearson correlation: {pearson_grav_sr[0]:.4f} (p-value: {pearson_grav_sr[1]:.4f})")
    print(f"Magnetic-SR Pearson correlation: {pearson_mag_sr[0]:.4f} (p-value: {pearson_mag_sr[1]:.4f})")
    
    print(f"Gravity-Magnetic Spearman correlation: {spearman_grav_mag[0]:.4f} (p-value: {spearman_grav_mag[1]:.4f})")
    print(f"Gravity-SR Spearman correlation: {spearman_grav_sr[0]:.4f} (p-value: {spearman_grav_sr[1]:.4f})")
    print(f"Magnetic-SR Spearman correlation: {spearman_mag_sr[0]:.4f} (p-value: {spearman_mag_sr[1]:.4f})")
    
    # Save results to file
    with open(os.path.join(PROCESSED_DIR, "correlation_metrics.txt"), "w") as f:
        f.write("Correlation Analysis Results:\n")
        f.write(f"Gravity-Magnetic Pearson correlation: {pearson_grav_mag[0]:.4f} (p-value: {pearson_grav_mag[1]:.4f})\n")
        f.write(f"Gravity-SR Pearson correlation: {pearson_grav_sr[0]:.4f} (p-value: {pearson_grav_sr[1]:.4f})\n")
        f.write(f"Magnetic-SR Pearson correlation: {pearson_mag_sr[0]:.4f} (p-value: {pearson_mag_sr[1]:.4f})\n\n")
        
        f.write(f"Gravity-Magnetic Spearman correlation: {spearman_grav_mag[0]:.4f} (p-value: {spearman_grav_mag[1]:.4f})\n")
        f.write(f"Gravity-SR Spearman correlation: {spearman_grav_sr[0]:.4f} (p-value: {spearman_grav_sr[1]:.4f})\n")
        f.write(f"Magnetic-SR Spearman correlation: {spearman_mag_sr[0]:.4f} (p-value: {spearman_mag_sr[1]:.4f})\n")
    
    return {
        'pearson': {
            'grav_mag': pearson_grav_mag,
            'grav_sr': pearson_grav_sr,
            'mag_sr': pearson_mag_sr
        },
        'spearman': {
            'grav_mag': spearman_grav_mag,
            'grav_sr': spearman_grav_sr,
            'mag_sr': spearman_mag_sr
        }
    }

def create_spatial_heatmaps(spatial_df):
    """Create spatial heatmaps for gravity, magnetic, and SR data."""
    print("Creating spatial heatmaps...")
    
    # Create a figure with three subplots
    fig, axes = plt.subplots(3, 1, figsize=(12, 18))
    
    # Define common parameters
    cmap = 'viridis'
    marker_size = 50
    alpha = 0.7
    
    # Plot 1: Gravity anomaly heatmap
    sc1 = axes[0].scatter(
        spatial_df['lon_grid'], 
        spatial_df['lat_grid'],
        c=spatial_df['bouguer_anomaly'],
        cmap=cmap,
        s=marker_size,
        alpha=alpha
    )
    axes[0].set_title('Bouguer Gravity Anomaly (mGal)')
    axes[0].set_xlabel('Longitude')
    axes[0].set_ylabel('Latitude')
    plt.colorbar(sc1, ax=axes[0])
    axes[0].grid(True, alpha=0.3)
    
    # Plot 2: Magnetic anomaly heatmap
    sc2 = axes[1].scatter(
        spatial_df['lon_grid'], 
        spatial_df['lat_grid'],
        c=spatial_df['magnetic_anomaly'],
        cmap=cmap,
        s=marker_size,
        alpha=alpha
    )
    axes[1].set_title('Simulated Magnetic Field Anomaly (nT)')
    axes[1].set_xlabel('Longitude')
    axes[1].set_ylabel('Latitude')
    plt.colorbar(sc2, ax=axes[1])
    axes[1].grid(True, alpha=0.3)
    
    # Plot 3: SR intensity heatmap
    sc3 = axes[2].scatter(
        spatial_df['lon_grid'], 
        spatial_df['lat_grid'],
        c=spatial_df['sr_intensity'],
        cmap=cmap,
        s=marker_size,
        alpha=alpha
    )
    axes[2].set_title('Simulated Schumann Resonance Intensity (arbitrary units)')
    axes[2].set_xlabel('Longitude')
    axes[2].set_ylabel('Latitude')
    plt.colorbar(sc3, ax=axes[2])
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'spatial_heatmaps.png'), dpi=300)
    plt.close()
    
    # Create correlation heatmaps
    create_correlation_heatmaps(spatial_df)
    
    print(f"Spatial heatmaps saved to {VISUALIZATION_DIR}")

def create_correlation_heatmaps(spatial_df):
    """Create correlation heatmaps between variables."""
    print("Creating correlation heatmaps...")
    
    # Create a figure with two subplots
    fig, axes = plt.subplots(1, 2, figsize=(18, 8))
    
    # Plot 1: Gravity vs Magnetic scatter with hexbin density
    hb = axes[0].hexbin(
        spatial_df['bouguer_anomaly'], 
        spatial_df['magnetic_anomaly'],
        gridsize=30, 
        cmap='viridis',
        mincnt=1
    )
    axes[0].set_title('Gravity vs Magnetic Field Correlation')
    axes[0].set_xlabel('Bouguer Gravity Anomaly (mGal)')
    axes[0].set_ylabel('Magnetic Field Anomaly (nT)')
    plt.colorbar(hb, ax=axes[0], label='Count')
    
    # Add regression line
    x = spatial_df['bouguer_anomaly']
    y = spatial_df['magnetic_anomaly']
    m, b = np.polyfit(x, y, 1)
    axes[0].plot(x, m*x + b, 'r-', alpha=0.7)
    
    # Plot 2: Gravity vs SR scatter with hexbin density
    hb2 = axes[1].hexbin(
        spatial_df['bouguer_anomaly'], 
        spatial_df['sr_intensity'],
        gridsize=30, 
        cmap='viridis',
        mincnt=1
    )
    axes[1].set_title('Gravity vs Schumann Resonance Correlation')
    axes[1].set_xlabel('Bouguer Gravity Anomaly (mGal)')
    axes[1].set_ylabel('SR Intensity (arbitrary units)')
    plt.colorbar(hb2, ax=axes[1], label='Count')
    
    # Add regression line
    x = spatial_df['bouguer_anomaly']
    y = spatial_df['sr_intensity']
    m, b = np.polyfit(x, y, 1)
    axes[1].plot(x, m*x + b, 'r-', alpha=0.7)
    
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'correlation_heatmaps.png'), dpi=300)
    plt.close()
    
    # Create correlation matrix heatmap
    plt.figure(figsize=(10, 8))
    corr_matrix = spatial_df[['bouguer_anomaly', 'magnetic_anomaly', 'sr_intensity']].corr()
    sns.heatmap(
        corr_matrix, 
        annot=True, 
        cmap='coolwarm', 
        vmin=-1, 
        vmax=1, 
        center=0,
        square=True,
        linewidths=.5
    )
    plt.title('Correlation Matrix Heatmap')
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, 'correlation_matrix.png'), dpi=300)
    plt.close()
    
    print(f"Correlation heatmaps saved to {VISUALIZATION_DIR}")

def main():
    """Main function to analyze spatial correlations."""
    print("Starting spatial correlation analysis...")
    
    # Load data
    gravity_df, sim_df = load_data()
    
    if gravity_df is not None and sim_df is not None:
        # Generate spatial grid from gravity data
        grid_df = generate_spatial_grid(gravity_df)
        
        # Simulate magnetic and SR spatial data
        spatial_df = simulate_magnetic_spatial_data(grid_df)
        
        # Save the spatial data
        spatial_df.to_csv(os.path.join(PROCESSED_DIR, 'spatial_grid_data.csv'), index=False)
        
        # Calculate correlation metrics
        correlation_metrics = calculate_correlation_metrics(spatial_df)
        
        # Create spatial heatmaps
        create_spatial_heatmaps(spatial_df)
        
        print("Spatial correlation analysis completed successfully.")
    else:
        print("Failed to perform spatial correlation analysis due to missing data.")

if __name__ == "__main__":
    main()
