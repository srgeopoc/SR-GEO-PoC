#!/usr/bin/env python3
"""
Preprocess gravity anomaly data for the Magnetic-Gravity Anomalies project.
This script processes the NOAA Africa gravity dataset to prepare it for analysis.
"""

import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from datetime import datetime

# Set paths - fixed to use absolute paths
DATA_DIR = "/home/ubuntu/magnetic_gravity_project/data"
OUTPUT_DIR = "/home/ubuntu/magnetic_gravity_project/data/processed"
VISUALIZATION_DIR = "/home/ubuntu/magnetic_gravity_project/visualizations"

# Create output directories if they don't exist
os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(VISUALIZATION_DIR, exist_ok=True)

def load_gravity_data(filename):
    """Load gravity data from CSV file."""
    print(f"Loading gravity data from {filename}...")
    try:
        # Load the data
        df = pd.read_csv(os.path.join(DATA_DIR, filename))
        print(f"Successfully loaded {len(df)} records.")
        return df
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

def preprocess_gravity_data(df):
    """Preprocess gravity data for analysis."""
    print("Preprocessing gravity data...")
    
    # Make a copy to avoid modifying the original
    processed_df = df.copy()
    
    # Check for missing values
    missing_values = processed_df.isnull().sum()
    print(f"Missing values before cleaning:\n{missing_values}")
    
    # Remove rows with missing values
    processed_df = processed_df.dropna()
    print(f"Records after removing missing values: {len(processed_df)}")
    
    # Calculate Bouguer anomaly (simplified calculation)
    # Bouguer anomaly = observed gravity - theoretical gravity - terrain correction
    # For simplicity, we'll use a very basic approximation
    # Theoretical gravity at sea level varies with latitude
    processed_df['theoretical_gravity'] = 978031.85 * (1 + 0.005278895 * np.sin(np.radians(processed_df['latitude']))**2)
    
    # Free-air correction (0.3086 mGal/m)
    processed_df['free_air_correction'] = 0.3086 * processed_df['sea_level_elev_m']
    
    # Simple Bouguer correction (0.0419 mGal/m for standard crustal density)
    processed_df['bouguer_correction'] = 0.0419 * processed_df['sea_level_elev_m']
    
    # Calculate gravity anomalies
    processed_df['free_air_anomaly'] = processed_df['obs_grav'] - processed_df['theoretical_gravity'] + processed_df['free_air_correction']
    processed_df['bouguer_anomaly'] = processed_df['free_air_anomaly'] - processed_df['bouguer_correction']
    
    # Add timestamp for time-series analysis (using current date as placeholder)
    # In a real scenario, we would use actual measurement dates
    current_date = datetime.now().strftime('%Y-%m-%d')
    processed_df['measurement_date'] = current_date
    
    return processed_df

def visualize_gravity_data(df, output_prefix):
    """Create visualizations of the gravity data."""
    print("Creating visualizations...")
    
    # Plot 1: Scatter plot of gravity measurements by location
    plt.figure(figsize=(12, 8))
    scatter = plt.scatter(
        df['longitude'], 
        df['latitude'], 
        c=df['bouguer_anomaly'], 
        cmap='viridis', 
        alpha=0.7,
        s=10
    )
    plt.colorbar(scatter, label='Bouguer Anomaly (mGal)')
    plt.title('Gravity Anomaly Distribution')
    plt.xlabel('Longitude')
    plt.ylabel('Latitude')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, f"{output_prefix}_spatial_distribution.png"), dpi=300)
    plt.close()
    
    # Plot 2: Histogram of Bouguer anomalies
    plt.figure(figsize=(10, 6))
    plt.hist(df['bouguer_anomaly'], bins=50, alpha=0.7, color='blue')
    plt.title('Distribution of Bouguer Anomalies')
    plt.xlabel('Bouguer Anomaly (mGal)')
    plt.ylabel('Frequency')
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(VISUALIZATION_DIR, f"{output_prefix}_histogram.png"), dpi=300)
    plt.close()
    
    print(f"Visualizations saved to {VISUALIZATION_DIR}")

def main():
    """Main function to process gravity data."""
    print("Starting gravity data preprocessing...")
    
    # Load the data
    gravity_df = load_gravity_data("africa.xyz")
    
    if gravity_df is not None:
        # Preprocess the data
        processed_df = preprocess_gravity_data(gravity_df)
        
        # Save processed data
        output_file = os.path.join(OUTPUT_DIR, "processed_gravity_data.csv")
        processed_df.to_csv(output_file, index=False)
        print(f"Processed data saved to {output_file}")
        
        # Create visualizations
        visualize_gravity_data(processed_df, "gravity")
        
        print("Gravity data preprocessing completed successfully.")
    else:
        print("Failed to process gravity data due to loading errors.")

if __name__ == "__main__":
    main()
