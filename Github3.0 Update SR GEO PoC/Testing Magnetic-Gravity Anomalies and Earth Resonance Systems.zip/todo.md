# Magnetic-Gravity Anomalies Project Todo

## Data Collection
- [x] Download gravity anomaly data (NOAA Africa dataset)
- [ ] Obtain SuperMAG magnetic field data
- [ ] Collect NOAA SR/ELF indexes
- [ ] Gather geomagnetic storm event data (Kp index)

## Data Processing
- [x] Preprocess and clean gravity data
- [ ] Preprocess and clean magnetic field data
- [ ] Preprocess and clean Schumann Resonance data
- [ ] Align all datasets to common time series format
- [ ] Create spatial grid for correlation analysis

## Visualization and Analysis
- [x] Create time-series overlays of magnetic index, SR amplitude, and gravity variation
- [x] Generate heatmaps showing spatial correlation between gravity and magnetic anomalies
- [x] Analyze correlation patterns during geomagnetic events
- [x] Test predictive overlap between magnetic fluctuations and microgravity anomalies

### Tesla-GRAVEM Model Integration
- [x] Implement Layer 1: Rotational Frame Drag (Spacetime vortex mapping)
- [x] Implement Layer 2: Spin-Phase Dynamics (Berry phase/coherence vs spin alignment)
- [x] Implement Layer 3: Earthfield Coupling (SR resonance + magneto-gravity feedback)
- [x] Validate model consistency and predictive powerrting
- [ ] Compile visualization results
- [ ] Document methodology and findings
- [ ] Prepare final report with conclusions
